#include <stdio.h>

int main() {
    float itemPrice = 1.50;  // Price of the item
    float amountInserted = 0.0;
    float coin=1.5;

    printf("Insert coins to purchase an item worth $1.50\n");

    // Collect coins until sufficient money is entered
    while (amountInserted < itemPrice) {
        amountInserted += coin;
    }

    printf("Item dispensed! Total amount inserted: $%.2f\n", amountInserted);
    return 0;
}