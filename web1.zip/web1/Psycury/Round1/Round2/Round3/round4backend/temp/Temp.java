class Temp {
public static void main(String[] args){
System.out.println("my name is adarsh");
}
}