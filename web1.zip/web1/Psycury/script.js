document.getElementById("startButton").addEventListener("click", function() {
    window.location.href = "Round1/index1.html"; // Replace with your desired page name
});
